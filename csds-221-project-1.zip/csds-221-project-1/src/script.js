// Abhinav Khanna
// axk1312
console.log("Hello");
$( document ).ready(function() {
    console.log( 'ready!' );
  });

  function updateCost(){
    let start = moment(document.getElementById('checkin').value);
    let end = moment(document.getElementById('checkout').value);

    //const days = end.diff(start,'days');
    const days = moment.duration(end.diff(start)).asDays();

    //const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    //console.log(days);

    let numberAdults = document.getElementById('adults-number').value;
    let cost = 150 * numberAdults * days;

    const $days = $('input[name="days"]');
    $days.val(days);

    const $cost = $('input[name="cost"]');
    $cost.val(cost);
    console.log(cost);
  }


  // Function to reset all the fields in the form
  function resetAll(){
    $('#bootstrap-form').reset;
    $('#username-parent').removeClass("has-error");
    $('#first-parent').removeClass("has-error");
    $('#last-parent').removeClass("has-error");
    $('#phone-parent').removeClass("has-error");
    $('#fax-parent').removeClass("has-error");
    $('#email-parent').removeClass("has-error");
    toastr.info("Form is reset");
  }

  // Function that validates all the fields and ensures that the entries are valid
  // This is called when the submit function is called
  function validate(){
    let flag = true;
    console.log($('#cost').val());
    // validate username
    if(!$('#username').val()){
        $('#username-parent').addClass("has-error");
        toastr.error("Please Enter the Username", "Username Error");
        flag = false;
    }else{
        $('#username-parent').removeClass("has-error");
    }
  
    // validate first name
    if(!$('#firstname').val()){
        $('#first-parent').addClass("has-error");
        toastr.error("Please Enter the First name", "Firstname Error");
        flag = false;
    }else{
        $('#first-parent').removeClass("has-error");
    }

    // validate last name
    if(!$('#lastname').val()){
        $('#last-parent').addClass("has-error");
        toastr.error("Please Enter the Last name", "Last name Error");
        flag = false;
    }else{
        $('#last-parent').removeClass("has-error");
    }

    // validate phone number
    if(!$('#phone').val()){
        $('#phone-parent').addClass("has-error");
        toastr.error("Please Enter the Phone Number", "Phone Number Error");
        flag = false;
    }else{
        $('#phone-parent').removeClass("has-error");
    }

    // validate fax
    if(!$('#fax').val()){
        $('#fax-parent').addClass("has-error");
        toastr.error("Please Enter the Fax Number", "Fax Number Error");
        flag = false;
    }else{
        $('#fax-parent').removeClass("has-error");
    }

    // validate email
    if(!$('#email').val()){
        $('#email-parent').addClass("has-error");
        toastr.error("Please Enter the Email", "Email Error");
        flag = false;
    }else{
        $('#email-parent').removeClass("has-error");
    }
    
    // validate cost
    if(!$('#cost').val()){
        toastr.error("The Cost has not been calculated", "Cost Error");
        flag = false;
    }else{
    // Check if Cost is positive
        if($('#cost').val()<0){
            toastr.error("Please make sure that the cost is positive", "Negative Cost Error");
            flag = false;
        }
    }

    // Checks if any of the fields have any error and if they don't then displays a green toaster 
    if(flag){
        toastr.success("Form Submitted Successfully", "Success");
    }
  }